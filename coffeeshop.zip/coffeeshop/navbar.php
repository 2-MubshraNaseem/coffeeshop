<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
    .navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    background-color: #3b141c;
    color: #fff;
    position: relative;
}

.nav-logo {
    display: flex;
    align-items: center;
    text-decoration: none;
}

.logo-text {
    font-size: 1.5rem;
    font-weight: bold;
    color: #ecf0f1;
}

.nav-menu {
    display: flex;
    justify-content: center;
    list-style: none;
    margin: 0;
    padding: 0;
    flex: 1;
}

.nav-item {
    margin: 0 10px;
}

.nav-link {
    text-decoration: none;
    color: #ecf0f1;
    font-size: 1rem;
    transition: color 0.3s ease;
}

.nav-link:hover {
    color: white;
    border-radius: 2px;
    border-bottom: 2px solid #e8890d;
}

.login-button {
    padding: 8px 16px;
    background-color: #1abc9c;
    color: #fff;
    border: none;
    border-radius: 5px;
    font-size: 1rem;
    cursor: pointer;
    margin: 2px;
    transition: background-color 0.3s ease;
}

.login-button:hover {
    background-color: #e8890d;
    color: #fff;
}

/* Mobile Styles */
.menu-toggle {
    display: none;
    background: none;
    border: none;
    color: #ecf0f1;
    font-size: 1.5rem;
    cursor: pointer;
}

@media (max-width: 768px) {
    .nav-menu {
        display: none;
        flex-direction: column;
        background-color: #34495e;
        position: absolute;
        top: 60px;
        left: 0;
        right: 0;
        width: 100%;
        padding: 10px 0;
        border-radius: 0 0 5px 5px;
    }

    .nav-menu.active {
        display: flex;
    }

    .nav-item {
        margin: 10px 0;
        text-align: center;
    }

    .menu-toggle {
        display: block;
    }

    .navbar {
        justify-content: space-between;
    }
}
</style>
</head>
<body>
<header>
        <nav class="navbar">
            <!-- Logo on the Left -->
            <a href="#" class="nav-logo">
                <h2 class="logo-text">☕ Coffee</h2>
            </a>

            <!-- Menu Toggle Button -->
            <button class="menu-toggle" id="menu-toggle">☰</button>

            <!-- Navigation Menu at the Center -->
            <ul class="nav-menu" id="nav-menu">
                <li class="nav-item">
                    <a href="ined.html/#home" class="nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="#about" class="nav-link">About</a>
                </li>
                <li class="nav-item">
                    <a href="#menu" class="nav-link">Menu</a>
                </li>
                <li class="nav-item">
                    <a href="#testimonials" class="nav-link">Testimonials</a>
                </li>
                <li class="nav-item">
                    <a href="#gallery" class="nav-link">Gallery</a>
                </li>
                <li class="nav-item">
                    <a href="#contact" class="nav-link">Contact</a>
                </li>
            </ul>

            <!-- Login Button on the Right -->
            <a href="signup.html"><button class="login-button">SignUp</button></a>
        </nav>
    </header>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
