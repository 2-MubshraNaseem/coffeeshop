<?php 
include "config.php";

$message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $customer_name = htmlspecialchars(trim($_POST["customer_name"]));
    $customer_email = filter_var(trim($_POST["customer_email"]), FILTER_SANITIZE_EMAIL);
    $product_category = htmlspecialchars(trim($_POST["product_category"]));
    $additional_request = htmlspecialchars(trim($_POST["additional_request"]));

    // Validate inputs
    if (empty($customer_name) || empty($customer_email) || empty($product_category)) {
        $message = "All fields except additional requests are required!";
    } elseif (!filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format!";
    } else {
        // Insert data into the database
        $stmt = $conn->prepare("INSERT INTO order_now (customer_name, customer_email, product_category, additional_request) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $customer_name, $customer_email, $product_category, $additional_request);

        if ($stmt->execute()) {
            $message = "Order placed successfully!";
        } else {
            $message = "Error placing order: " . $stmt->error;
        }

        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place Your Order</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #573818;
        }
        .order-container {
            max-width: 800px;
            margin: auto;
            margin-top: 50px;
            padding: 20px;
            background-color: rgba(161, 109, 14, 1);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .order-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2e1700;
        }
        .form-control {
            color: #2e1700;
        }
        .btn {
            background-color:#2e1700;
            color: #fff;
        }
        .btn:hover {
            background-color: rgb(183, 95, 7);
            color: #2e1700;
            border: none;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="order-container">
        <h2>Place Your Order</h2>
        <?php if (!empty($message)): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>
        <form action="order.php" method="POST">
            <div class="form-group">
                <label for="customer_name" style="color:white">Name</label>
                <input type="text" class="form-control" id="customer_name" name="customer_name" required>
            </div>
            <div class="form-group">
                <label for="customer_email" style="color:white">Email</label>
                <input type="email" class="form-control" id="customer_email" name="customer_email" required>
            </div>
            <div class="form-group">
                <label for="product_category" style="color:white">Select Category</label>
                <select class="form-control" id="product_category" name="product_category" required>
                    <option value="">Choose a category</option>
                    <option value="Vanilla">Espresso</option>
                    <option value="Chocolate">Cappuccino</option>
                    <option value="Strawberry">Latte</option>
                    <option value="Strawberry">Americano</option>
                    <option value="Strawberry">Mocha</option>
                    <option value="Strawberry">Flat White</option>
                </select>
            </div>
            <div class="form-group">
                <label for="additional_request" style="color:white">Additional Requests</label>
                <textarea class="form-control" id="additional_request" name="additional_request" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Submit Order</button>
        </form>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
