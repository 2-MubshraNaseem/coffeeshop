<?php
require "config.php"; // Database connection

if (isset($_GET["token"])) {
    $token = $_GET["token"];
} else {
    die("Invalid request.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = password_hash($_POST["new_password"], PASSWORD_DEFAULT);

    // Update password
    $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL WHERE reset_token = ?");
    $stmt->bind_param("ss", $new_password, $token);
    if ($stmt->execute()) {
        echo "Password updated! <a href='login.html'>Login</a>";
    } else {
        echo "Error updating password.";
    }
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Password</title>
</head>
<body>
    <h2>Set New Password</h2>
    <form action="" method="POST">
        <label for="new_password">New Password:</label>
        <input type="password" id="new_password" name="new_password" required><br>
        <button type="submit">Reset Password</button>
    </form>
</body>
</html>
