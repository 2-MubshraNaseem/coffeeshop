<?php
include 'db.php';

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Insert data into the table
$sql = "INSERT INTO contact_form (name, email, message) VALUES ('$name', '$email','$message')";

if ($conn->query($sql) === TRUE) {
    echo "Your message has been sent!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
