<?php
$host = "localhost"; // Change if using a different host
$username = "root"; // Change according to your DB user
$password = ""; // Change if you have a DB password
$database = "coffee_shop";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
