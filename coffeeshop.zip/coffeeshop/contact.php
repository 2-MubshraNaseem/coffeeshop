<?php
// Database connection settings
$servername = "localhost"; // Change this to your database server
$username = "root";        // Database username
$password = "";            // Database password
$dbname = "coffee_shop";   // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Validate form data (you can add more validation if necessary)
    if (empty($name) || empty($email) || empty($message)) {
        echo "<script>alert('All fields are required.');</script>";
    } else {
        // Prepare and bind SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO  contact_form (name, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $message);

        // Execute the statement
        if ($stmt->execute()) {
            // Success message
            echo "<script>alert('Message sent successfully!');</script>";
        } else {
            // Error message
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #2e1700;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #e8890d;
            color: #fff;
            position: relative;
        }
        .nav-logo {
            display: flex;
            align-items: center;
            text-decoration: none;
        }
        .logo-text {
            font-size: 1.5rem;
            font-weight: bold;
            color: #2e1700;
            text-decoration: none;
        }
        .logo-text:hover{
            text-decoration: none;
        }
        .nav-menu {
            display: flex;
            justify-content: center;
            list-style: none;
            margin: 0;
            padding: 0;
            flex: 1;
        }
        .nav-item {
            margin: 0 10px;
        }
        .nav-link {
            text-decoration: none;
            color: #2e1700;
            font-size: 1rem;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: white;
            border-radius: 2px;
            border-bottom: 2px solid #e8890d;
        }
        .login-button {
            padding: 8px 16px;
            background-color: #1abc9c;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            margin: 2px;
            transition: background-color 0.3s ease;
        }
        .login-button:hover {
            background-color: #3b141c;
            color: #fff;
        }

        .contact-container {
            background-color: rgb(161,109 , 14,1);
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .contact-container h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #2e1700;
        }
        .contact-container p {
            text-align: center;
            color: white;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #ffffff;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #573818;
            color: white;
        }
        .btn {
            background-color: #2e1700;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            font-weight: 500;
            align-items: center;
            justify-content: center;
        }
        .btn:hover {
            background-color: #fff;
            color: #2e1700;
            font-weight: bold;
        }
        footer.footer-section {
    display: flex;
    flex-direction: column; /* Stack main sections and bottom text */
    align-items: center;
    padding: 20px;
    background-color: #3b141c; /* Background color */
}

footer .main-footer {
    width: 100%; /* Full width for proper spacing */
    display: flex;
    justify-content: space-between; /* Align sections (left, center, right) */
    align-items: center;
    padding-bottom: 10px;
}

.section-content {
    color: #fff;
    font-size: 16px;
}

footer .social-link-list {
    display: flex;
    gap: 10px; /* Space between social icons */
}

footer .social-link-list a {
    text-decoration: none;
    font-size: 18px;
    color: #3b141c;
    transition: color 0.3s ease;
    background-color: #1abc9c;
    padding: 10px 10px;
    border-radius: 40px;
}

footer .social-link-list a:hover {
    color: #000;
    background-color: #e8890d; /* Change color on hover */
}

footer .policy-text {
    display: flex;
    gap: 10px; /* Space between privacy links */
    font-size: 14px;
}

footer .policy-text a {
    text-decoration: none;
    color: #fff;
    transition: color 0.3s ease;
}

footer .policy-text a:hover {
    color: #e8890d;
}

footer .policy-text .separator {
    margin: 0 5px;
    color: #e8890d;
}

footer .bottom {
    width: 100%; /* Full width for alignment */
    text-align: center;
    border-top: 1px solid #fff; /* Separator line */
    margin-top: 20px;
    padding-top: 10px;
    color: #fff;
    font-size: 14px;
    font-style: italic;
}

footer .bottom p {
    margin: 0;
}

    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <a href="#" class="nav-logo">
                <h2 class="logo-text">☕ Coffee</h2>
            </a>
            <ul class="nav-menu" id="nav-menu">
                <li class="nav-item"><a href="#home" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="#about" class="nav-link">About</a></li>
                <li class="nav-item"><a href="#menu" class="nav-link">Menu</a></li>
                <li class="nav-item"><a href="#testimonials" class="nav-link">Testimonials</a></li>
                <li class="nav-item"><a href="#gallery" class="nav-link">Gallery</a></li>
                <li class="nav-item"><a href="#contact" class="nav-link">Contact</a></li>
            </ul>
            <a href="signup.html"><button class="login-button">SignUp</button></a>
        </nav>
    </header>
    <div class="contact-container">
        <h1>Get in Touch</h1>
        <p>Please fill out this form and always be in touch with us</p>
        <form action="contact.php" method="post">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="message">Message:</label>
                <textarea id="message" name="message" required></textarea>
            </div>
            <div class="text-center mt-4">
                <button class="btn btn-primary">Send Message</button>
            </div>
        </form>
    </div>
    <footer class="footer-section">
        <div class="main-footer">
            <div class="section-content">
                <p>© 2025 ☕coffee Shop</p>
            </div>
            <div class="social-link-list">
                <a href="#" class="social-link"><i class="fa-brands fa-facebook"></i></a>
                <a href="#" class="social-link"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" class="social-link"><i class="fa-brands fa-twitter"></i></a>
            </div>
            <div class="policy-text">
                <a href="#">Privacy Policy</a><span class="separator">|</span><a href="#">Terms of Service</a>
            </div>
        </div>
        <div class="bottom">
            <p>© 2023 Mubshra Naseem “All Rights Reserved”</p>
        </div>
    </footer>
</body>
</html>
