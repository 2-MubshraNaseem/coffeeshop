<?php include 'navbar.php'; ?>

<?php

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 690px;
            
        }

        h1 {
            color: #3b141c;
        }

        p {
            font-size: 16px;
            color: #555;
            margin-bottom: 20px;
        }

        .logout-btn {
            background-color: #3b141c;
            color: white;
            border: none;
            padding: 10px;
            width: 80%;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .logout-btn:hover {
            background-color: #e8890d;
            font-weight: bold;
            color: #3b141c;
            border: 2px solid #3b141c;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['email']); ?>!</h1>
        <p>You're successfully logged in.</p>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

</body>
</html>
